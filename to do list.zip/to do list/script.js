const container = document.getElementById('container');
const registerToggle = document.getElementById('register');
const loginToggle = document.getElementById('login');

registerToggle.addEventListener('click', () => {
  container.classList.add("active");
});

loginToggle.addEventListener('click', () => {
  container.classList.remove("active");
});

document.getElementById("loginForm").addEventListener("submit", function(e){
  e.preventDefault(); 

  // Optional: bisa validasi dulu input email & password
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  if(email && password){
      window.location.href = "dashboard.html";
  } else {
      alert("Please fill email and password");
  }
});

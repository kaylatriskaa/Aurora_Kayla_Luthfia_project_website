function logoutConfirm() {
    Swal.fire({
      title: 'Are you sure you want to logout?',
      text: "Kamu akan keluar dari akun :(",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya, logout',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire(
          'Logout!',
          'Anda telah logout.',
          'success'
        ).then(() => {
          window.location.href = "sign.html"; 
        });
      }
    });
}

function SaveConfirm() {
    Swal.fire({
        title: "Do you want to save the changes?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Save",
        denyButtonText: `Don't save`
    }).then((result) => {
        if (result.isConfirmed) {
            const name = document.getElementById("title").value;
            const email = document.getElementById("email").value;
            const contact = document.getElementById("contact").value;
            const photoSrc = document.getElementById("photo").src;

            // Simpan ke localStorage
            localStorage.setItem("profileName", name);
            localStorage.setItem("profileEmail", email);
            localStorage.setItem("profileContact", contact);
            localStorage.setItem("profilePhoto", photoSrc);

            Swal.fire("Saved!", "", "success").then(() => {
                location.reload(); // Reload supaya langsung kelihatan perubahannya
            });
        } else if (result.isDenied) {
            Swal.fire("Changes are not saved", "", "info");
        }
    });
}


const monthYearElement = document.getElementById('monthYear');
const datesElement = document.getElementById('dates');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let currentDate = new Date();

const updateCalendar = () => {
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();

    const firstDay = new Date(currentYear, currentMonth,1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const totalDays = lastDay.getDate();
    const firstDayIndex = firstDay.getDay();
    const lastDayIndex = lastDay.getDay();

    const monthYearString = currentDate.toLocaleString('default', {
        month: 'long', 
        year: 'numeric'
    });
    monthYearElement.textContent = monthYearString;

    let datesHTML = '';

    for (let i = firstDayIndex; i > 0; i--) {
        const prevDate = new Date(currentYear,currentMonth, 0 - i + 1);
        datesHTML += `<div class="date inactive">${prevDate.getDate()}</div>`;
    }

    for (let i = 1; i <= totalDays; i++) {
        const date = new Date(currentYear, currentMonth, i);
        const activeClass = date.toDateString() === new Date().toDateString() ? 'active' : '';
        datesHTML += `<div class="date ${activeClass}">${i}</div>`;
    }

    for (let i  = 1; i <= (6 - lastDayIndex); i++) {
        const nextDate = new Date(currentYear, currentMonth + 1, i);
        datesHTML += `<div class="date inactive">${nextDate.getDate()}</div>`;
    }

    datesElement.innerHTML = datesHTML;
}

prevBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    updateCalendar();
})

nextBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    updateCalendar();

})

updateCalendar();

function toggle() {
    const popup = document.getElementById("pops");
    popup.style.display = (popup.style.display === "none" || popup.style.display === "") ? "flex" : "none";
}

const photo = document.getElementById("photo");
const fileInput = document.getElementById("file");
const sideImg = document.querySelector(".side-img");

fileInput.addEventListener("change", function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function (e) {
            const imageUrl = e.target.result;
            photo.src = imageUrl;               // Foto di form ganti
            sideImg.style.backgroundImage = `url(${imageUrl})`;  // Sidebar ganti
        };

        reader.readAsDataURL(file);
    }
});

// Ambil data dari localStorage saat halaman dibuka
window.addEventListener("DOMContentLoaded", () => {
    const savedName = localStorage.getItem("profileName");
    const savedEmail = localStorage.getItem("profileEmail");
    const savedContact = localStorage.getItem("profileContact");
    const savedPhoto = localStorage.getItem("profilePhoto");

    

    if (savedName) {
        document.getElementById("title").value = savedName;
        document.querySelector(".user p").textContent = savedName;
    }
    if (savedEmail) {
        document.getElementById("email").value = savedEmail;
        document.querySelector(".user small").textContent = savedEmail;
    }
    if (savedContact) {
        document.getElementById("contact").value = savedContact;
    }
    if (savedPhoto) {
        document.getElementById("photo").src = savedPhoto;
        document.querySelector(".side-img").style.backgroundImage = `url(${savedPhoto})`;
    }
});

window.addEventListener("DOMContentLoaded", () => {
    const savedName = localStorage.getItem("profileName");
    const savedEmail = localStorage.getItem("profileEmail");
    const savedPhoto = localStorage.getItem("profilePhoto");

    if (savedName) {
        document.getElementById("title").value = savedName;
        document.querySelector(".user p").textContent = savedName;
    }
    if (savedEmail) {
        document.getElementById("email").value = savedEmail;
        document.querySelector(".user small").textContent = savedEmail;
    }
    if (savedPhoto) {
        document.getElementById("photo").src = savedPhoto;
        document.querySelector(".side-img").style.backgroundImage = `url(${savedPhoto})`;
    }

    // Setelah isi semua, baru munculin
    document.querySelector(".sidebar").style.visibility = "visible";
    document.querySelector(".side-img").style.visibility = "visible";
    document.querySelector(".user p").style.visibility = "visible";
    document.querySelector(".user small").style.visibility = "visible";
});


function toggleBlur() {
    const blur = document.getElementById('blur');
    const popup = document.getElementById('popup');
    if (blur && popup) {
      blur.classList.toggle('active');
      popup.classList.toggle('active');
    } else {
      console.error('Elemen #blur atau #popup tidak ditemukan!');
    }
}


const monthYearElement = document.getElementById('monthYear');
const datesElement = document.getElementById('dates');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let currentDate = new Date();

const updateCalendar = () => {
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();

    const firstDay = new Date(currentYear, currentMonth,1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const totalDays = lastDay.getDate();
    const firstDayIndex = firstDay.getDay();
    const lastDayIndex = lastDay.getDay();

    const monthYearString = currentDate.toLocaleString('default', {
        month: 'long', 
        year: 'numeric'
    });
    monthYearElement.textContent = monthYearString;

    let datesHTML = '';

    for (let i = firstDayIndex; i > 0; i--) {
        const prevDate = new Date(currentYear,currentMonth, 0 - i + 1);
        datesHTML += `<div class="date inactive">${prevDate.getDate()}</div>`;
    }

    for (let i = 1; i <= totalDays; i++) {
        const date = new Date(currentYear, currentMonth, i);
        const activeClass = date.toDateString() === new Date().toDateString() ? 'active' : '';
        datesHTML += `<div class="date ${activeClass}">${i}</div>`;
    }

    for (let i  = 1; i <= (6 - lastDayIndex); i++) {
        const nextDate = new Date(currentYear, currentMonth + 1, i);
        datesHTML += `<div class="date inactive">${nextDate.getDate()}</div>`;
    }

    datesElement.innerHTML = datesHTML;
}

prevBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    updateCalendar();
})

nextBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    updateCalendar();

})

updateCalendar();

function toggle() {
    const popup = document.getElementById("pops");
    popup.style.display = (popup.style.display === "none" || popup.style.display === "") ? "flex" : "none";
}

// Base URL untuk API
const API_URL = 'http://localhost:5000/Tasks';

function convertToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });
}

// Fungsi untuk mengambil semua task
async function SaveConfirm() {
    const title = document.getElementById('title').value;
    const date = document.getElementById('date').value;
    const desc = document.getElementById('desc').value;
    const fileInput = document.getElementById('file');
    const imageFile = fileInput.files[0];

    let imageBase64 = null;
    if (imageFile) {
        imageBase64 = await convertToBase64(imageFile);
    }

    const taskData = {
        title,
        date,
        desc,
        ...(imageBase64 && { image: imageBase64 })
    };
    
    const form = document.getElementById('taskForm');
    const editId = form.getAttribute('data-edit-id');

    try {
        let response;

        if (editId) {
            // Edit mode
            response = await fetch(`${API_URL}/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });

            form.removeAttribute('data-edit-id'); // Reset mode
        } else {
            // Add mode
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        }

        if (!response.ok) throw new Error(await response.text());

        Swal.fire("Tersimpan!", "", "success").then(() => {
            toggleBlur();
            fetchTasks();
            form.reset();

            checkForTaskNotification(date);
        });

    } catch (error) {
        Swal.fire("Error!", error.message, "error");
    }
}

// Fungsi untuk memeriksa apakah tanggal task adalah hari ini
function checkTodayTasks(tasks) {
    const today = new Date().toISOString().split('T')[0];

    const todayTasks = tasks.filter(task => {
        const taskDate = new Date(task.date).toISOString().split('T')[0];
        return taskDate === today;
    });

    if (todayTasks.length > 0) {
        showNotification(todayTasks); 
    }
}


// Fungsi untuk menampilkan notifikasi
function showNotification(tasks) {
    const notifBox = document.getElementById('notification');
    


// Pasang event listener untuk klik notif
    notifBox.addEventListener('click', async () => {
    try {
        const response = await fetch(API_URL);
        const tasks = await response.json();
    

        const today = new Date().toISOString().split('T')[0];

        const todayTasks = tasks.filter(task => {
            const taskDate = new Date(task.date).toISOString().split('T')[0];
            return taskDate === today;
        });

        if (todayTasks.length > 0) {
            showNotification(todayTasks); // <-- Panggil Swal kalau ada task
        } else {
            Swal.fire({
                title: "Tidak ada task hari ini!",
                text: "Santai dulu atau buat rencana baru ✨",
                icon: "info",
                confirmButtonColor: "#8000FF"
            });
        }

    } catch (error) {
        console.error('Gagal ambil task:', error);
        Swal.fire({
            title: "Error!",
            text: "Gagal memuat task",
            icon: "error",
            confirmButtonColor: "#8000FF"
        });
    }
});

    if (!document.getElementById('notif-dot')) {
        const dot = document.createElement('span');
        dot.id = 'notif-dot';
        dot.style.cssText = `
            position: absolute;
            top: -2px;
            right: -2px;
            background: red;
            width: 10px;
            height: 10px;
            border-radius: 50%;
        `;
        notifBox.appendChild(dot);
        
     
    }
    
    const taskListHTML = tasks.map((task, index) => `
        <div style="
            background: #f5f0ff; 
            border: 1px solid #c9b3ff; 
            border-radius: 8px; 
            padding: 10px 15px; 
            margin-bottom: 10px;
            text-align: left;
            display: flex;
            align-items: center;
            gap: 8px;
        ">
            <span style="font-size: 20px;">📌</span>
            <div>
                <div style="font-weight: bold;">${task.title}</div>
                <div style="color: #555; font-size: 13px;">📅 ${new Date(task.date).toLocaleDateString()}</div>
              
            </div>
        </div>
    `).join('');

    Swal.fire({
        title: "📅 Task untuk hari ini!",
        html: `
            <div style="font-size: 16px; max-height: 300px; overflow-y: auto;">
                ${taskListHTML}
            </div>
        `,
        icon: "info",
        confirmButtonColor: "#8000FF",
        confirmButtonText: "Gas kerjain! 🚀",
        width: 600,
        background: "#ffffff",
        backdrop: `
            rgba(0,0,123,0.3)
            center top
            no-repeat
        `
    }).then(() => {
        const checkboxes = document.querySelectorAll('.task-checkbox');
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (event) => {
                const index = event.target.dataset.index;
                tasks[index].completed = event.target.checked; // Update task status
                
                // Cek jika semua task selesai
                const allCompleted = tasks.every(task => task.completed);
                
                // Jika semua task selesai, hilangkan dot merah dan tampilkan Swal
                if (allCompleted) {
                    document.getElementById('notif-dot').style.display = 'none';
                    Swal.fire({
                        title: "Semua task selesai!",
                        text: "Tidak ada task hari ini ✨",
                        icon: "info",
                        confirmButtonColor: "#8000FF"
                    });
                }

                // Jika ada task yang belum selesai, tampilkan dot merah
                else {
                    document.getElementById('notif-dot').style.display = 'block';
                }
            });
        });
    });            
}




function renderTasks(tasks) {
    const container = document.getElementById('task-list');
    if (!container) {
        console.error('❌ Elemen #task-list TIDAK ditemukan!');
        return;
    }

    container.innerHTML = '';

    tasks.forEach(task => {
        const taskElement = document.createElement('div');
        taskElement.className = 'card-product';

        taskElement.innerHTML = `
            <div class="task-item" ${task.completed ? 'completed' : ''}" data-id="${task.id}">
                <div class="task-left">
                    <label class="checkbox-container">
                        <input type="checkbox" ${task.completed ? 'checked' : ''}>
                        <span class="checkmark"></span>
                    </label>
                    <div class="task-text">
                        <h4>${task.title}</h4>
                        <p>${task.desc}</p>
                        <small>${new Date(task.date).toLocaleDateString() || 'Invalid Date'}</small>
                    </div>
                </div>
                <div class="plan-right">
                    ${task.image ? `<img src="${task.image}" alt="Task image">` : ''}
                    <div class="task-actions">
                        <button class="edit-btn">✏️</button>
                        <button class="delete-btn">🗑️</button>
                    </div>
                </div>
            </div>
        `;

        // Tambahkan event listener untuk edit dan delete
        taskElement.querySelector('.edit-btn').addEventListener('click', () => {
            openEditPopup(task);
        });

        taskElement.querySelector('.delete-btn').addEventListener('click', () => {
            confirmDelete(task.id);
        });

        container.appendChild(taskElement);

        taskElement.querySelector('input[type="checkbox"]').addEventListener('change', async function () {
            const isChecked = this.checked;
        
            // Tambah/hapus class "completed"
            const taskContainer = taskElement.querySelector('.task-item');
            if (isChecked) {
                taskContainer.classList.add('completed');
            } else {
                taskContainer.classList.remove('completed');
            }
        
            // Simpan ke backend
            try {
                await fetch(`${API_URL}/${task.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ completed: isChecked })
                });
            } catch (err) {
                console.error('Gagal update status task:', err);
            }
        });
        
    });

    
}



function openEditPopup(task) {
    toggleBlur(); // munculkan popup

    // isi form dengan data lama
    document.getElementById('title').value = task.title;
    document.getElementById('desc').value = task.desc;
    document.getElementById('date').value = task.date.slice(0, 10); // Format YYYY-MM-DD

    // Simpan ID task yang akan di-edit
    document.getElementById('taskForm').setAttribute('data-edit-id', task.id);
}

async function confirmDelete(id) {
    const confirm = await Swal.fire({
        title: "Yakin ingin hapus?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Hapus",
        cancelButtonText: "Batal",
    });

    if (confirm.isConfirmed) {
        await deleteTask(id);
    }
}

async function deleteTask(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Gagal hapus task');

        fetchTasks(); // Refresh list
        Swal.fire("Dihapus!", "", "success");
    } catch (error) {
        Swal.fire("Error!", error.message, "error");
    }
}



document.addEventListener('DOMContentLoaded', () => {
    fetchTasks(); // Panggil saat halaman siap
});

async function fetchTasks() {
    try {
        const response = await fetch(API_URL);
        const tasks = await response.json();
        console.log("TASKS DARI BACKEND:", tasks); // <-- Tambahan log
        renderTasks(tasks);

        checkTodayTasks(tasks);

    } catch (error) {
        console.error('Fetch error:', error);
    }
}

const searchInput = document.querySelector('input[type="text"]');

searchInput.addEventListener('input', async function () {
    const keyword = this.value.toLowerCase();
    
    try {
        const response = await fetch(API_URL);
        let tasks = await response.json();

        if (keyword.trim() !== '') {
            // Urutkan berdasarkan kecocokan judul/desc
            tasks = tasks.filter(task => 
                task.title.toLowerCase().includes(keyword) ||
                task.desc.toLowerCase().includes(keyword)
            );
        }

        renderTasks(tasks);
    } catch (error) {
        console.error('Search fetch error:', error);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });

});

window.addEventListener("DOMContentLoaded", () => {
    const savedName = localStorage.getItem("profileName");
    const savedEmail = localStorage.getItem("profileEmail");
    const savedPhoto = localStorage.getItem("profilePhoto");

    if (savedName) {
        document.querySelector(".user p").textContent = savedName;
    }
    if (savedEmail) {
        document.querySelector(".user small").textContent = savedEmail;
    }
    if (savedPhoto) {
        document.querySelector(".side-img").style.backgroundImage = `url(${savedPhoto})`;
    }
});

  



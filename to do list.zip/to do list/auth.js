const baseURL = "http://localhost:4000"; // ganti sesuai URL backend kamu

// Register
document.getElementById("registerForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  
  try {
    const res = await axios.post(${baseURL}/register, {
      name: document.getElementById("registerName").value,
      email: document.getElementById("registerEmail").value,
      password: document.getElementById("registerPassword").value
    }, {
      withCredentials: true // penting untuk cookie
    });

    alert("Register berhasil! Silakan login.");
    console.log(res.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    alert("Gagal register!");
  }
});

// Login
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  try {
    const res = await axios.post(${baseURL}/login, {
      email: document.getElementById("loginEmail").value,
      password: document.getElementById("loginPassword").value
    }, {
      withCredentials: true
    });

    alert("Login berhasil!");
    console.log(res.data);
  } catch (err) {
    console.error(err.response?.data || err.message);
    alert("Gagal login!");
  }
});
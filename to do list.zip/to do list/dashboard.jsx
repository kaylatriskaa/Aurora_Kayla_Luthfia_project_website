import { useState } from "react";

const Dashboard = () => {
  const [tasks, setTasks] = useState([
    {
      title: "Pergi ke sekolah",
      description:
        "Belajar yang rajin di sekolah, tes senam jangan lupa, bawa baju olahraga jangan lupa, beli dimsum dan cincau cap panda.",
      priority: "Moderate",
      status: "Not started",
      created: "22/01/2025",
      image: "school.jpg",
    },
    {
      title: "Ngerjain patung",
      description: "Buat patung woi !!!!! #SOEKARNO MANTAP",
      priority: "Moderate",
      status: "In progress",
      created: "22/01/2025",
      image: "sculpture.jpg",
    },
  ]);

  const completedPlans = [
    {
      title: "Hafalin senam",
      description: "Hafalin senam buat hari kamis harus sampe bisa pokoknya jangan liat video.",
      status: "Completed",
      completedDate: "One day ago",
      image: "school.jpg",
    },
  ];

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center bg-white p-4 shadow-md rounded-lg">
        <h1 className="text-2xl font-bold">Hello, Su Zai Zai >&lt;</h1>
        <input
          type="text"
          placeholder="Search your task here..."
          className="border px-4 py-2 rounded-lg"
        />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-3 gap-4 mt-6">
        {/* To-do List */}
        <div className="col-span-2 bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">To-do</h2>
          {tasks.map((task, index) => (
            <div key={index} className="border p-4 rounded-lg mb-4">
              <h3 className="font-bold">{task.title}</h3>
              <p>{task.description}</p>
              <p className="text-sm">
                <strong>Priority:</strong> {task.priority} | <strong>Status:</strong> {task.status}
              </p>
            </div>
          ))}
        </div>

        {/* Plan Status */}
        <div className="bg-white p-4 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Plan Status</h2>
          <div className="flex justify-around">
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-green-500 rounded-full"></div>
              <p>Completed</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-blue-500 rounded-full"></div>
              <p>In Progress</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 border-4 border-red-500 rounded-full"></div>
              <p>Not Started</p>
            </div>
          </div>
        </div>
      </div>

      {/* Completed Plans */}
      <div className="mt-6 bg-white p-4 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Completed Plan</h2>
        {completedPlans.map((plan, index) => (
          <div key={index} className="border p-4 rounded-lg mb-4">
            <h3 className="font-bold">{plan.title}</h3>
            <p>{plan.description}</p>
            <p className="text-sm">
              <strong>Status:</strong> {plan.status} | <strong>Completed:</strong> {plan.completedDate}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;

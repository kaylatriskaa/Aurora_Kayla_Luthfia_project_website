<?php
// Koneksi ke database
$host = 'localhost';
$dbname = 'planit';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=planit", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}

// Proses upload gambar
$imagePath = null;
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploads/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    $filename = uniqid() . '_' . basename($_FILES['image']['name']);
    $targetPath = $uploadDir . $filename;
    
    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
        $imagePath = $targetPath;
    }
}

// Simpan data ke database
try {
    $stmt = $conn->prepare("INSERT INTO tasks (title, task_date, description, image_path) 
                           VALUES (:title, :task_date, :description, :image_path)");
    
    $stmt->bindParam(':title', $_POST['title']);
    $stmt->bindParam(':task_date', $_POST['date']);
    $stmt->bindParam(':description', $_POST['description']);
    $stmt->bindParam(':image_path', $imagePath);
    
    $stmt->execute();
    
    // Redirect ke halaman sukses
    header("Location: plan.html?status=success");
    exit();
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
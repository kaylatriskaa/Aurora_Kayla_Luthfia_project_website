document.addEventListener("DOMContentLoaded", function () {
    const start = document.getElementById("start");
    const stop = document.getElementById("stop");
    const reset = document.getElementById("reset");
    const timer = document.getElementById("timer");

    let timeleft = 1500;
    let interval;

    const updateTimer = () => {
        const minutes = Math.floor(timeleft / 60);
        const seconds = timeleft % 60;
        timer.innerHTML = `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    };

    const startTimer = () => {
        clearInterval(interval);
        interval = setInterval(() => {
            timeleft--;
            updateTimer();

            if (timeleft <= 0) {
                clearInterval(interval);
                alert("Time's up!");
                timeleft = 1500;
                updateTimer();
            }
        }, 1000);
    };

    const stopTimer = () => clearInterval(interval);
    const resetTimer = () => {
        clearInterval(interval);
        timeleft = 1500;
        updateTimer();
    };

    start.addEventListener("click", startTimer);
    stop.addEventListener("click", stopTimer);
    reset.addEventListener("click", resetTimer);

    updateTimer();
});


const monthYearElement = document.getElementById('monthYear');
const datesElement = document.getElementById('dates');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');

let currentDate = new Date();

const updateCalendar = () => {
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth();

    const firstDay = new Date(currentYear, currentMonth,1);
    const lastDay = new Date(currentYear, currentMonth + 1, 0);
    const totalDays = lastDay.getDate();
    const firstDayIndex = firstDay.getDay();
    const lastDayIndex = lastDay.getDay();

    const monthYearString = currentDate.toLocaleString('default', {
        month: 'long', 
        year: 'numeric'
    });
    monthYearElement.textContent = monthYearString;

    let datesHTML = '';

    for (let i = firstDayIndex; i > 0; i--) {
        const prevDate = new Date(currentYear,currentMonth, 0 - i + 1);
        datesHTML += `<div class="date inactive">${prevDate.getDate()}</div>`;
    }

    for (let i = 1; i <= totalDays; i++) {
        const date = new Date(currentYear, currentMonth, i);
        const activeClass = date.toDateString() === new Date().toDateString() ? 'active' : '';
        datesHTML += `<div class="date ${activeClass}">${i}</div>`;
    }

    for (let i  = 1; i <= (6 - lastDayIndex); i++) {
        const nextDate = new Date(currentYear, currentMonth + 1, i);
        datesHTML += `<div class="date inactive">${nextDate.getDate()}</div>`;
    }

    datesElement.innerHTML = datesHTML;
}

prevBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    updateCalendar();
})

nextBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    updateCalendar();

})

updateCalendar();

function toggle() {
    const popup = document.getElementById("pops");
    popup.style.display = (popup.style.display === "none" || popup.style.display === "") ? "flex" : "none";
}
function toggleBlur() {
    const blur = document.getElementById('blur');
    const popup = document.getElementById('popup');
    if (blur && popup) {
      blur.classList.toggle('active');
      popup.classList.toggle('active');
    } else {
      console.error('Elemen #blur atau #popup tidak ditemukan!');
    }
}

// Base URL untuk API
const API_URL = 'http://localhost:5000/Tasks';
const baseURL = "http://localhost:5000"; 


function convertToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = (error) => reject(error);
    });
}

// Fungsi untuk mengambil semua task
async function SaveConfirm() {
    const title = document.getElementById('title').value;
    const date = document.getElementById('date').value;
    const desc = document.getElementById('desc').value;
    const fileInput = document.getElementById('file');
    const imageFile = fileInput.files[0];

    let imageBase64 = null;
    if (imageFile) {
        imageBase64 = await convertToBase64(imageFile);
    }

    const taskData = {
        title,
        date,
        desc,
        ...(imageBase64 && { image: imageBase64 })
    };
    
    const form = document.getElementById('taskForm');
    const editId = form.getAttribute('data-edit-id');

    try {
        let response;

        if (editId) {
            // Edit mode
            response = await fetch(`${API_URL}/${editId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });

            form.removeAttribute('data-edit-id'); // Reset mode
        } else {
            // Add mode
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        }

        if (!response.ok) throw new Error(await response.text());

        Swal.fire("Tersimpan!", "", "success").then(() => {
            toggleBlur();
            fetchTasks();
            form.reset();
        });

    } catch (error) {
        Swal.fire("Error!", error.message, "error");
    }
}



// Fungsi untuk update progress bar
function updateProgressBars(tasks) {
    const totalTasks = tasks.length;
    if (totalTasks === 0) return; // Hindari pembagian dengan 0
    
    const completedCount = tasks.filter(task => task.completed).length;
    const notStartedCount = totalTasks - completedCount;
    
    const completedPercent = Math.round((completedCount / totalTasks) * 100);
    const notStartedPercent = 100 - completedPercent;
    
    // Update progress bar width
    document.getElementById('completed-bar').style.width = `${completedPercent}%`;
    document.getElementById('notstarted-bar').style.width = `${notStartedPercent}%`;
    
    // Update persentase text
    document.getElementById('completed-percent').textContent = `${completedPercent}%`;
    document.getElementById('notstarted-percent').textContent = `${notStartedPercent}%`;
}

function renderTasks(tasks) {
    const container = document.getElementById('task-list');
    if (!container) {
        console.error('❌ Elemen #task-list TIDAK ditemukan!');
        return;
    }

    container.innerHTML = '';

    tasks.slice(0, 3).forEach(task => {

        const taskElement = document.createElement('div');
        taskElement.className = `simple-task-card ${task.completed ? 'completed' : ''}`;
        taskElement.setAttribute('data-id', task.id);

        taskElement.innerHTML = `
            <label class="checkbox-container">
                <input type="checkbox" ${task.completed ? 'checked' : ''}>
                <span class="checkmark"></span>
            </label>
            <h4>${task.title}</h4>
            <div class="task-actions">
                <button class="edit-btn"><i class="fa-solid fa-pen"></i></button>
                <button class="delete-btn"><i class="fa-solid fa-trash"></i></button>
            </div>
        `;

        // Event listener untuk checkbox
        taskElement.querySelector('input[type="checkbox"]').addEventListener('change', async function(e) {
            e.preventDefault(); // mencegah perilaku default (kalau ada form)
            e.stopPropagation(); // mencegah bubbling event ke parent lain
        
            const isChecked = this.checked;
        
            // Update tampilan
            if (isChecked) {
                taskElement.classList.add('completed');
            } else {
                taskElement.classList.remove('completed');
            }
            
            // Update ke backend
            try {
                await fetch(`${API_URL}/${task.id}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ completed: isChecked })
                });
            } catch (err) {
                console.error('Gagal update status task:', err);
            }
        });

        // Event listener untuk tombol edit
        taskElement.querySelector('.edit-btn').addEventListener('click', () => {
            openEditPopup(task);
        });

        // Event listener untuk tombol delete
        taskElement.querySelector('.delete-btn').addEventListener('click', () => {
            confirmDelete(task.id);
        });

        container.appendChild(taskElement);
    });

    updateProgressBars(tasks);
}

// Fungsi cek notifikasi berdasarkan tanggal task
async function checkTaskNotifications() {
    try {
        const response = await fetch(API_URL);
        const tasks = await response.json();

        const today = new Date().toISOString().split('T')[0]; // Format YYYY-MM-DD
        const todayTasks = tasks.filter(task => task.date === today && !task.completed);

        if (todayTasks.length > 0) {
            showNotification(todayTasks);
        }
    } catch (error) {
        console.error("Gagal cek notifikasi:", error);
    }
}

// Fungsi munculin notifikasi
function showNotification(tasks) {
    const notifBox = document.getElementById('notification');

    // Tambah indikator visual (contoh: titik merah)
    if (!document.getElementById('notif-dot')) {
        const dot = document.createElement('span');
        dot.id = 'notif-dot';
        dot.style.cssText = `
            position: absolute;
            top: -2px;
            right: -2px;
            background: red;
            width: 10px;
            height: 10px;
            border-radius: 50%;
        `;
        notifBox.appendChild(dot);
    }

    notifBox.addEventListener('click', () => {
        let taskList = tasks.map(task => `• ${task.title} (📅 ${task.date})`).join('\n');
        Swal.fire({
            title: 'Task untuk hari ini!',
            text: taskList,
            icon: 'info',
            confirmButtonText: 'Oke'
        });

        // Hapus titik merah setelah dibuka
        const dot = document.getElementById('notif-dot');
        if (dot) dot.remove();
    });
}

document.addEventListener('DOMContentLoaded', () => {
    checkTaskNotifications(); // Cek saat load halaman
});


function openEditPopup(task) {
    toggleBlur(); // munculkan popup

    // isi form dengan data lama
    document.getElementById('title').value = task.title;
    document.getElementById('desc').value = task.desc;
    document.getElementById('date').value = task.date.slice(0, 10); // Format YYYY-MM-DD

    // Simpan ID task yang akan di-edit
    document.getElementById('taskForm').setAttribute('data-edit-id', task.id);
}

async function confirmDelete(id) {
    const confirm = await Swal.fire({
        title: "Yakin ingin hapus?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Hapus",
        cancelButtonText: "Batal",
    });

    if (confirm.isConfirmed) {
        await deleteTask(id);
    }
}

async function deleteTask(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Gagal hapus task');

        fetchTasks(); // Refresh list
        Swal.fire("Dihapus!", "", "success");
    } catch (error) {
        Swal.fire("Error!", error.message, "error");
    }
}



document.addEventListener('DOMContentLoaded', () => {
    fetchTasks(); // Panggil saat halaman siap
});

async function fetchTasks() {
    try {
        const response = await fetch(API_URL);
        const tasks = await response.json();
        console.log("TASKS DARI BACKEND:", tasks); // <-- Tambahan log
        renderTasks(tasks);
        return tasks;
    } catch (error) {
        console.error('Fetch error:', error);
    }
}

const searchInput = document.querySelector('input[type="text"]');

searchInput.addEventListener('input', async function () {
    const keyword = this.value.toLowerCase();
    
    try {
        const response = await fetch(API_URL);
        let tasks = await response.json();

        if (keyword.trim() !== '') {
            // Urutkan berdasarkan kecocokan judul/desc
            tasks = tasks.filter(task => 
                task.title.toLowerCase().includes(keyword) ||
                task.desc.toLowerCase().includes(keyword)
            );
        }

        renderTasks(tasks);
    } catch (error) {
        console.error('Search fetch error:', error);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });

});

async function fetchUserData() {
  try {
    const token = localStorage.getItem("token");
    const res = await axios.get(`${baseURL}/Users`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    document.getElementById("userInfo").innerText = JSON.stringify(res.data, null, 2);
  } catch (err) {
    if (err.response?.status === 403) {
      try {
        const res = await axios.get(`${baseURL}/token`, {
          withCredentials: true
        });
        const newToken = res.data.accessToken;
        localStorage.setItem("token", newToken);
        fetchUserData(); // coba lagi
      } catch {
        alert("Sesi habis, silakan login lagi");
        window.location.href = "sign.html";
      }
    }
  } 
}

fetchUserData();

window.addEventListener("DOMContentLoaded", () => {
    const savedName = localStorage.getItem("profileName");
    const savedEmail = localStorage.getItem("profileEmail");
    const savedContact = localStorage.getItem("profileContact");
    const savedPhoto = localStorage.getItem("profilePhoto");

    if (savedName) {
        document.getElementById("title").value = savedName;
        document.querySelector(".user p").textContent = savedName;
    }
    if (savedEmail) {
        document.getElementById("email").value = savedEmail;
        document.querySelector(".user small").textContent = savedEmail;
    }
    if (savedContact) {
        document.getElementById("contact").value = savedContact;
    }
    if (savedPhoto) {
        document.getElementById("photo").src = savedPhoto;
        document.querySelector(".side-img").style.backgroundImage = `url(${savedPhoto})`;
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const savedName = localStorage.getItem("profileName");
    const savedEmail = localStorage.getItem("profileEmail");
    const savedPhoto = localStorage.getItem("profilePhoto");

    if (savedName) {
        document.querySelector(".user p").textContent = savedName;
    }
    if (savedEmail) {
        document.querySelector(".user small").textContent = savedEmail;
    }
    if (savedPhoto) {
        document.querySelector(".side-img").style.backgroundImage = `url(${savedPhoto})`;
    }

    document.querySelector(".sidebar").style.visibility = "visible";
});


import express from "express";
import { getUsers, Register, Login, Logout } from "../controllers/Users.js";
import { verifyToken } from "../middleware/VerifyToken.js";
import { refreshToken } from "../controllers/RefreshToken.js";

const router = express.Router();

router.get('/Users', verifyToken, getUsers);
router.post('/Register', Register);
router.post('/Login', Login);
router.get('/token', refreshToken);
router.delete('/Logout', Logout);

export default router;